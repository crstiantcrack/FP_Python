b = int(input("Ingrese el valor de la base:"))
a = int(input("Ingrese el valor del perimetro: "))

area = b * a
perimetro = 2*(b+a)

print(f"La area del rectangulo es: {area} m²")
print(f"El perimetro del rectangulo es: {perimetro} m")