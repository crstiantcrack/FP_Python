num = input("Ingrese un número entero positivo de 4 cifras: ")

suma= int(num[0]) + int(num[1]) + int(num[2]) + int(num[3])

print(suma)