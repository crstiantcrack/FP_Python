num1 = input("el numero a invertir es: ")
numero_inver = num1 [::-1]

print(numero_inver)